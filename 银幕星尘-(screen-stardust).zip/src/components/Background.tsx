/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion, AnimatePresence } from 'motion/react';
import { ArchetypeCode } from '../types';
import { ARCHETYPES, SPLASH_IMAGE } from '../constants';

interface BackgroundProps {
  currentVibe: ArchetypeCode | 'default';
}

export default function Background({ currentVibe }: BackgroundProps) {
  const colors = currentVibe === 'default' 
    ? ['#050505', '#1a1a1a'] 
    : ARCHETYPES[currentVibe].colors;

  return (
    <div className="fixed inset-0 -z-10 overflow-hidden bg-black">
      {/* Splash Image for Landing */}
      <AnimatePresence>
        {currentVibe === 'default' && (
          <motion.div
            initial={{ opacity: 0, scale: 1.1, filter: 'blur(10px)' }}
            animate={{ opacity: 0.5, scale: 1, filter: 'blur(0px)' }}
            exit={{ opacity: 0, scale: 1.05, filter: 'blur(20px)' }}
            transition={{ duration: 2, ease: "easeInOut" }}
            className="absolute inset-0"
          >
            <img 
              src={SPLASH_IMAGE} 
              alt="Sci-fi Splash" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/20 to-black/80" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Layered Gradients */}
      <motion.div
        animate={{
          background: `radial-gradient(circle at 20% 30%, ${colors[0]}33 0%, transparent 70%),
                       radial-gradient(circle at 80% 70%, ${colors[1]}33 0%, transparent 70%)`,
        }}
        transition={{ duration: 2, ease: "easeInOut" }}
        className="absolute inset-0"
      />

      {/* Animated Particles / Noise */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none mix-blend-overlay">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] bg-repeat" />
      </div>

      {/* Floating Orbs */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentVibe}
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 0.4, scale: 1 }}
          exit={{ opacity: 0, scale: 1.2 }}
          transition={{ duration: 3, ease: "easeOut" }}
          className="absolute inset-0 flex items-center justify-center pointer-events-none"
        >
          <div 
            className="w-[80vw] h-[80vw] rounded-full blur-[120px]"
            style={{ 
              background: `radial-gradient(circle, ${colors[0]}66 0%, transparent 70%)` 
            }}
          />
        </motion.div>
      </AnimatePresence>

      {/* Scanline Effect */}
      <div className="absolute inset-0 pointer-events-none bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%] z-50 opacity-20" />
    </div>
  );
}
