/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useRef, useState } from 'react';
import { motion } from 'motion/react';
import html2canvas from 'html2canvas';
import { Archetype } from '../types';
import { Download, Share2, RefreshCw } from 'lucide-react';
import { cn } from '../lib/utils';

interface ResultCardProps {
  archetype: Archetype;
  onRestart: () => void;
}

export default function ResultCard({ archetype, onRestart }: ResultCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const handleDownload = async () => {
    if (!cardRef.current) return;
    setIsGenerating(true);
    try {
      const canvas = await html2canvas(cardRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#000',
      });
      const link = document.createElement('a');
      link.download = `screen-stardust-${archetype.code}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } catch (err) {
      console.error('Failed to generate poster:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Simple Radar Chart Component
  const RadarChart = ({ data }: { data: Archetype['radar'] }) => {
    const size = 120;
    const center = size / 2;
    const radius = size * 0.4;
    const points = [
      { x: center, y: center - radius * (data.rational / 100), label: '理性' },
      { x: center + radius * (data.emotional / 100) * Math.cos(Math.PI / 10), y: center + radius * (data.emotional / 100) * Math.sin(Math.PI / 10), label: '感性' },
      { x: center + radius * (data.order / 100) * Math.cos(Math.PI / 2 + Math.PI / 5), y: center + radius * (data.order / 100) * Math.sin(Math.PI / 2 + Math.PI / 5), label: '秩序' },
      { x: center - radius * (data.chaos / 100) * Math.cos(Math.PI / 2 + Math.PI / 5), y: center + radius * (data.chaos / 100) * Math.sin(Math.PI / 2 + Math.PI / 5), label: '混沌' },
      { x: center - radius * (data.fate / 100) * Math.cos(Math.PI / 10), y: center + radius * (data.fate / 100) * Math.sin(Math.PI / 10), label: '宿命' },
    ];

    const pathData = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') + ' Z';

    return (
      <div className="relative w-[120px] h-[120px]">
        <svg width={size} height={size} className="overflow-visible">
          {/* Grid */}
          {[0.2, 0.4, 0.6, 0.8, 1].map((r, i) => (
            <circle key={i} cx={center} cy={center} r={radius * r} fill="none" stroke="white" strokeOpacity="0.1" strokeWidth="0.5" />
          ))}
          {/* Axis */}
          {points.map((p, i) => {
            const angle = (i * 2 * Math.PI) / 5 - Math.PI / 2;
            const tx = center + radius * Math.cos(angle);
            const ty = center + radius * Math.sin(angle);
            return (
              <line key={i} x1={center} y1={center} x2={tx} y2={ty} stroke="white" strokeOpacity="0.1" strokeWidth="0.5" />
            );
          })}
          {/* Data Path */}
          <path d={pathData} fill={archetype.colors[0]} fillOpacity="0.3" stroke={archetype.colors[0]} strokeWidth="1.5" />
        </svg>
        {/* Labels could be added here if needed, but keeping it minimal for "Vibe" */}
      </div>
    );
  };

  return (
    <div className="w-full max-w-md mx-auto pb-20">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative"
      >
        {/* Poster Container */}
        <div 
          ref={cardRef}
          className="relative aspect-[9/16] bg-black overflow-hidden border border-white/10 shadow-2xl"
        >
          {/* Background Image */}
          <div className="absolute inset-0">
            <motion.img 
              initial={{ scale: 1.2, opacity: 0 }}
              animate={{ scale: 1, opacity: 0.7 }}
              transition={{ duration: 2, ease: "easeOut" }}
              src={archetype.visualSymbol} 
              alt={archetype.name}
              className="w-full h-full object-cover grayscale-[0.3] contrast-[1.1] brightness-[0.8]"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
            <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-transparent" />
          </div>

          {/* Content Overlay */}
          <div className="absolute inset-0 p-8 flex flex-col justify-between">
            {/* Top Header */}
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <p className="text-[8px] font-mono tracking-[0.3em] text-white/40 uppercase">Subject Identification</p>
                <h3 className="text-xl font-light tracking-tighter text-white">
                  {archetype.code} <span className="opacity-40">/</span> {archetype.title}
                </h3>
              </div>
              <div className="w-8 h-8 border border-white/20 flex items-center justify-center">
                <div className="w-3 h-3 bg-white/80 animate-pulse" />
              </div>
            </div>

            {/* Middle Section */}
            <div className="flex-1 flex flex-col justify-center py-10">
              <motion.div
                initial={{ x: -20, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="space-y-5"
              >
                <div className="space-y-2">
                  <h1 className="text-4xl font-bold tracking-tighter text-white leading-none">
                    {archetype.name}
                  </h1>
                  <p className="text-xs font-mono text-white/60 italic">{archetype.movie}</p>
                </div>

                <div className="flex flex-wrap gap-2">
                  {archetype.tags.map((tag, i) => (
                    <span key={i} className="px-2 py-0.5 border border-white/20 text-[8px] text-white/80 uppercase tracking-wider">
                      {tag}
                    </span>
                  ))}
                </div>

                <p className="text-xs leading-relaxed text-white/70 font-light max-w-[85%]">
                  {archetype.description}
                </p>
              </motion.div>
            </div>

            {/* Bottom Section */}
            <div className="flex items-end justify-between">
              <div className="space-y-4">
                <RadarChart data={archetype.radar} />
                <div className="space-y-1">
                  <p className="text-[8px] font-mono text-white/30 uppercase tracking-[0.2em]">Atmosphere Vibe</p>
                  <p className="text-[10px] text-white/60">{archetype.vibe}</p>
                </div>
              </div>
              
              <div className="text-right space-y-2">
                <div className="inline-block p-2 border border-white/10 bg-white/5 backdrop-blur-sm">
                  <div className="w-16 h-16 bg-white/10 flex items-center justify-center">
                    <span className="text-[8px] text-white/20 font-mono rotate-90">SCAN QR</span>
                  </div>
                </div>
                <p className="text-[10px] font-mono text-white/40">SCREEN STARDUST © 2026</p>
              </div>
            </div>
          </div>

          {/* Decorative Borders */}
          <div className="absolute top-4 left-4 right-4 bottom-4 border border-white/5 pointer-events-none" />
        </div>

        {/* Action Buttons */}
        <div className="mt-8 grid grid-cols-2 gap-4 px-4">
          <button
            onClick={handleDownload}
            disabled={isGenerating}
            className={cn(
              "flex items-center justify-center gap-2 py-4 rounded-full bg-white text-black font-medium transition-all active:scale-95",
              isGenerating && "opacity-50 cursor-not-allowed"
            )}
          >
            <Download size={18} />
            <span>{isGenerating ? '生成中...' : '保存海报'}</span>
          </button>
          <button
            onClick={onRestart}
            className="flex items-center justify-center gap-2 py-4 rounded-full border border-white/20 text-white font-medium backdrop-blur-md transition-all active:scale-95"
          >
            <RefreshCw size={18} />
            <span>重新测试</span>
          </button>
        </div>
      </motion.div>
    </div>
  );
}
