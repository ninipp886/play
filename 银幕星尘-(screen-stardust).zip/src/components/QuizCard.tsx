/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { Question, Option } from '../types';
import { cn } from '../lib/utils';
import { ArrowLeft } from 'lucide-react';

interface QuizCardProps {
  question: Question;
  onSelect: (option: Option) => void;
  onBack: () => void;
  currentIndex: number;
  total: number;
}

export default function QuizCard({ question, onSelect, onBack, currentIndex, total }: QuizCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -20, scale: 0.95 }}
      transition={{ duration: 0.5, ease: [0.23, 1, 0.32, 1] }}
      className="w-full max-w-lg mx-auto"
    >
      <div className="mb-8 space-y-2">
        <div className="flex justify-between items-end">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-white/40 hover:text-white transition-colors group/back"
          >
            <ArrowLeft size={12} className="group-hover/back:-translate-x-1 transition-transform" />
            <span>返回</span>
          </button>
          <span className="text-[10px] font-mono text-white/60">
            {String(currentIndex + 1).padStart(2, '0')} / {total}
          </span>
        </div>
        <div className="h-[1px] w-full bg-white/10 overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: `${((currentIndex + 1) / total) * 100}%` }}
            className="h-full bg-white/40"
          />
        </div>
      </div>

      <div className="relative group">
        {/* Glass Card */}
        <div className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl p-8 shadow-2xl">
          <h2 className="text-lg md:text-xl font-light leading-relaxed text-white mb-10 tracking-tight">
            {question.text}
          </h2>

          <div className="space-y-4">
            {question.options.map((option, idx) => (
              <motion.button
                key={idx}
                whileHover={{ scale: 1.01, backgroundColor: "rgba(255, 255, 255, 0.08)" }}
                whileTap={{ scale: 0.99 }}
                onClick={() => onSelect(option)}
                className={cn(
                  "w-full text-left p-4 rounded-xl border border-white/5 bg-white/5",
                  "transition-all duration-300 group/btn relative overflow-hidden"
                )}
              >
                <div className="flex items-start gap-4">
                  <span className="text-[9px] font-mono text-white/30 mt-1.5">
                    {String.fromCharCode(65 + idx)}
                  </span>
                  <p className="text-xs md:text-sm text-white/80 leading-relaxed group-hover/btn:text-white transition-colors">
                    {option.text}
                  </p>
                </div>
                {/* Hover Glow */}
                <div className="absolute inset-0 bg-gradient-to-r from-white/0 via-white/5 to-white/0 -translate-x-full group-hover/btn:translate-x-full transition-transform duration-1000" />
              </motion.button>
            ))}
          </div>
        </div>
        
        {/* Decorative Elements */}
        <div className="absolute -top-4 -right-4 w-24 h-24 bg-white/5 rounded-full blur-2xl -z-10" />
        <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-white/5 rounded-full blur-3xl -z-10" />
      </div>
    </motion.div>
  );
}
