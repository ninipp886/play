/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppState, ArchetypeCode, Option } from './types';
import { QUESTIONS, ARCHETYPES } from './constants';
import Background from './components/Background';
import QuizCard from './components/QuizCard';
import ResultCard from './components/ResultCard';
import { cn } from './lib/utils';
import { Sparkles, Terminal, ChevronRight } from 'lucide-react';

export default function App() {
  const [state, setState] = useState<AppState>('splash');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<ArchetypeCode[]>([]);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [processingText, setProcessingText] = useState('');

  // Determine current vibe based on the last answer or default
  const currentVibe = useMemo(() => {
    if (state === 'splash') return 'default';
    if (answers.length > 0) return answers[answers.length - 1];
    return 'default';
  }, [state, answers]);

  const handleStart = () => {
    setState('quiz');
  };

  const handleSelectOption = (option: Option) => {
    const newAnswers = [...answers, option.code];
    setAnswers(newAnswers);

    if (currentQuestionIndex < QUESTIONS.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      startProcessing();
    }
  };

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
      setAnswers(prev => prev.slice(0, -1));
    } else {
      setState('splash');
    }
  };

  const startProcessing = () => {
    setState('processing');
    const texts = [
      "正在建立意识上行链路...",
      "正在解构时间线...",
      "匹配物理常数...",
      "人格拟合完毕"
    ];
    
    let textIdx = 0;
    const textInterval = setInterval(() => {
      setProcessingText(texts[textIdx]);
      textIdx++;
      if (textIdx >= texts.length) clearInterval(textInterval);
    }, 800);

    const progressInterval = setInterval(() => {
      setProcessingProgress(prev => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          setTimeout(() => setState('result'), 500);
          return 100;
        }
        // Non-linear progress
        const increment = Math.random() * 15;
        return Math.min(prev + increment, 100);
      });
    }, 400);
  };

  const getResult = () => {
    const counts: Record<ArchetypeCode, number> = {
      R1: 0, R2: 0, R3: 0, R4: 0, R5: 0, R6: 0
    };
    answers.forEach(code => counts[code]++);
    
    // Priority: R6 > R5 > R1 > R3 > R4 > R2
    const priority: ArchetypeCode[] = ['R6', 'R5', 'R1', 'R3', 'R4', 'R2'];
    let maxCount = -1;
    let result: ArchetypeCode = 'R6';

    priority.forEach(code => {
      if (counts[code] > maxCount) {
        maxCount = counts[code];
        result = code;
      }
    });

    return ARCHETYPES[result];
  };

  const handleRestart = () => {
    setState('splash');
    setCurrentQuestionIndex(0);
    setAnswers([]);
    setProcessingProgress(0);
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center overflow-x-hidden selection:bg-white selection:text-black">
      <Background currentVibe={currentVibe} />

      <AnimatePresence mode="wait">
        {state === 'splash' && (
          <motion.div
            key="splash"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center text-center px-6"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1, ease: "easeOut" }}
              className="mb-12"
            >
              <div className="relative inline-block">
                <h1 className="text-5xl md:text-7xl font-black tracking-tighter text-white uppercase italic">
                  银幕星尘
                </h1>
                <div className="absolute -top-6 -right-6">
                  <Sparkles className="text-white/40 w-6 h-6 animate-pulse" />
                </div>
              </div>
              <p className="mt-4 text-[10px] md:text-xs font-mono tracking-[0.4em] text-white/40 uppercase">
                Screen Stardust Protocol
              </p>
            </motion.div>

            <motion.p
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="max-w-[280px] text-white/60 text-xs leading-relaxed mb-12 font-light"
            >
              基于科幻电影美学与深层心理学，<br />
              扫描你的维度坐标，解构你的灵魂原型。
            </motion.p>

            <motion.button
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.8 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleStart}
              className="group relative px-10 py-4 overflow-hidden"
            >
              {/* Sci-fi Button Background */}
              <div className="absolute inset-0 bg-white/5 backdrop-blur-md border border-white/20 transition-colors group-hover:bg-white/10 group-hover:border-white/40" />
              
              {/* Corner Accents */}
              <div className="absolute top-0 left-0 w-2 h-2 border-t-2 border-l-2 border-white/60" />
              <div className="absolute top-0 right-0 w-2 h-2 border-t-2 border-r-2 border-white/60" />
              <div className="absolute bottom-0 left-0 w-2 h-2 border-b-2 border-l-2 border-white/60" />
              <div className="absolute bottom-0 right-0 w-2 h-2 border-b-2 border-r-2 border-white/60" />

              {/* Scanning Line */}
              <div className="absolute inset-0 w-full h-[1px] bg-white/20 -translate-y-full group-hover:animate-[scan_2s_linear_infinite]" />

              <span className="relative z-10 flex items-center gap-3 text-white text-xs font-bold uppercase tracking-[0.3em] group-hover:text-glow transition-all">
                <Terminal size={14} className="text-white/60" />
                接入系统
                <ChevronRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </span>
            </motion.button>
          </motion.div>
        )}

        {state === 'quiz' && (
          <motion.div
            key="quiz"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full px-6"
          >
            <QuizCard
              question={QUESTIONS[currentQuestionIndex]}
              onSelect={handleSelectOption}
              onBack={handleBack}
              currentIndex={currentQuestionIndex}
              total={QUESTIONS.length}
            />
          </motion.div>
        )}

        {state === 'processing' && (
          <motion.div
            key="processing"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center text-center px-6 w-full max-w-sm"
          >
            <Terminal className="w-12 h-12 text-white/40 mb-8 animate-pulse" />
            <div className="w-full h-[2px] bg-white/10 mb-4 overflow-hidden">
              <motion.div 
                className="h-full bg-white"
                initial={{ width: 0 }}
                animate={{ width: `${processingProgress}%` }}
              />
            </div>
            <div className="flex justify-between w-full mb-8 font-mono text-[10px] text-white/40 uppercase tracking-widest">
              <span>Analysis in progress</span>
              <span>{Math.round(processingProgress)}%</span>
            </div>
            <AnimatePresence mode="wait">
              <motion.p
                key={processingText}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="text-sm font-mono text-white/80 tracking-wider"
              >
                {processingText}
              </motion.p>
            </AnimatePresence>
          </motion.div>
        )}

        {state === 'result' && (
          <motion.div
            key="result"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="w-full px-4 py-10"
          >
            <ResultCard archetype={getResult()} onRestart={handleRestart} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer Info */}
      <div className="fixed bottom-6 left-0 right-0 flex justify-center pointer-events-none">
        <p className="text-[8px] font-mono text-white/20 uppercase tracking-[0.5em]">
          Vibecoding Protocol v1.0.42
        </p>
      </div>
    </div>
  );
}
