/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ArchetypeCode = 'R1' | 'R2' | 'R3' | 'R4' | 'R5' | 'R6';

export interface Archetype {
  code: ArchetypeCode;
  name: string;
  title: string;
  movie: string;
  vibe: string;
  tags: string[];
  description: string;
  visualSymbol: string;
  radar: {
    rational: number;
    emotional: number;
    order: number;
    chaos: number;
    fate: number;
  };
  colors: [string, string]; // [primary, secondary]
}

export interface Option {
  text: string;
  code: ArchetypeCode;
}

export interface Question {
  id: number;
  volume: string;
  text: string;
  options: Option[];
}

export type AppState = 'splash' | 'quiz' | 'processing' | 'result';
