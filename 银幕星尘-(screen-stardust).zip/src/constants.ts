/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Archetype, Question } from './types';

export const SPLASH_IMAGE = 'https://picsum.photos/seed/nebula/1920/1080';

export const ARCHETYPES: Record<string, Archetype> = {
  R1: {
    code: 'R1',
    name: '孤独的漫游者',
    title: 'Lonely Wanderer',
    movie: '《银翼杀手 2049》',
    vibe: '霓虹、雨夜、赛博朋克',
    tags: ['寻真', '忧郁', '自我觉醒'],
    description: '你是在霓虹雨夜中寻找真实记忆的漫游者。在虚幻的景观社会中，你依然珍视那一丝微弱的、属于灵魂的震颤。你明白，即使记忆是植入的，感受也依然真实。',
    visualSymbol: 'https://w.wallhaven.cc/full/73/wallhaven-73ml69.png',
    radar: { rational: 60, emotional: 90, order: 40, chaos: 70, fate: 80 },
    colors: ['#ff00ea', '#00f2ff'],
  },
  R2: {
    code: 'R2',
    name: '真理的破壁人',
    title: 'Truth Breaker',
    movie: '《黑客帝国》',
    vibe: '矩阵绿、黑客代码流',
    tags: ['觉醒', '反叛', '意志'],
    description: '你拒绝接受被定义的现实。你是代码世界中的异数，是敢于吞下红药丸、直面残酷真相的勇者。对你而言，自由意志高于一切物理法则。',
    visualSymbol: 'https://w.wallhaven.cc/full/5d/wallhaven-5d3em9.png',
    radar: { rational: 80, emotional: 50, order: 30, chaos: 95, fate: 60 },
    colors: ['#00ff41', '#003b00'],
  },
  R3: {
    code: 'R3',
    name: '星际的守望者',
    title: 'Interstellar Watcher',
    movie: '《星际穿越》',
    vibe: '深空蓝、五维书架',
    tags: ['承诺', '时间', '引力'],
    description: '你相信爱是唯一可以超越维度、跨越光年的物理常量。你是时间的守望者，在无尽 of 幽闭中，那份跨越星系的连接是你永恒的锚点。',
    visualSymbol: 'https://w.wallhaven.cc/full/yx/wallhaven-yxzmog.png',
    radar: { rational: 70, emotional: 95, order: 60, chaos: 40, fate: 85 },
    colors: ['#001233', '#00a8ff'],
  },
  R4: {
    code: 'R4',
    name: '秩序的先行者',
    title: 'Order Pioneer',
    movie: '《沙丘》',
    vibe: '金色废土、巨型几何',
    tags: ['天命', '权力', '意志'],
    description: '你是行走在金色沙海中的天命之子。你理解权力的残酷，也明白秩序的代价。在巨型建筑的阴影下，你正以铁腕和信仰重塑星系的未来。',
    visualSymbol: 'https://w.wallhaven.cc/full/5g/wallhaven-5g8wv1.jpg',
    radar: { rational: 75, emotional: 40, order: 95, chaos: 30, fate: 90 },
    colors: ['#ff9d00', '#4a3728'],
  },
  R5: {
    code: 'R5',
    name: '文明的沟通者',
    title: 'Civilization Communicator',
    movie: '《降临》',
    vibe: '冷灰迷雾、水墨环形',
    tags: ['智性', '悲悯', '非线性'],
    description: '你拥有跨越物种界限的共情力。你理解时间的非线性本质，在迷雾中与未知文明对话。你坦然拥抱已知的结局，因为经历本身就是意义。',
    visualSymbol: 'https://w.wallhaven.cc/full/ox/wallhaven-oxv9e5.png',
    radar: { rational: 85, emotional: 80, order: 70, chaos: 50, fate: 75 },
    colors: ['#8e9294', '#2c3e50'],
  },
  R6: {
    code: 'R6',
    name: '深空的合奏者',
    title: 'The Deep Space Harmonizer',
    movie: '《挽救计划》',
    vibe: '纯白实验室、金色闪烁',
    tags: ['极客', '解题', '乐观'],
    description: '你是宇宙中最顶尖的解题者。在孤立无援的绝境中，你依然能以纯粹的理性和幽默感，用科学的火种照亮文明延续的道路。',
    visualSymbol: 'https://w.wallhaven.cc/full/nz/wallhaven-nzxlxj.jpg',
    radar: { rational: 98, emotional: 60, order: 85, chaos: 20, fate: 50 },
    colors: ['#f1c40f', '#ffffff'],
  },
};

export const QUESTIONS: Question[] = [
  {
    id: 1,
    volume: '第一卷：危机与降临',
    text: '当你在一艘陌生的星际飞船中醒来，周围空无一人，你的第一反应是？',
    options: [
      { text: '寻找控制面板，检查飞船底层代码是否存在逻辑漏洞或被外部接管的痕迹。', code: 'R2' },
      { text: '立刻寻找实验室和测量工具，计算当前的重力、温度等物理常数，判断所处环境。', code: 'R6' },
      { text: '走到巨大的玻璃舷窗前，凝视深空，感受那种被整个宇宙抛弃的极致孤独。', code: 'R1' },
    ],
  },
  {
    id: 2,
    volume: '第一卷：危机与降临',
    text: '探险队在废墟中挖掘出一个来源不明的几何体，它似乎在微微震动。你会？',
    options: [
      { text: '记录它的震动频率，尝试用数学模型或图形建立与它的沟通桥梁。', code: 'R5' },
      { text: '认为这是一种强大的遗迹资源，思考如何利用它建立新的秩序和信仰。', code: 'R4' },
      { text: '靠近它，看它是否能与你的心跳产生共鸣，或许它携带着某人的记忆。', code: 'R3' },
    ],
  },
  {
    id: 3,
    volume: '第一卷：危机与降临',
    text: '如果文明注定要在一百年后毁灭，且无法逆转，你会主张怎样度过最后的岁月？',
    options: [
      { text: '倾尽全球资源建造方舟，哪怕只有万分之一的几率，也要把科学火种送出去。', code: 'R6' },
      { text: '接受这个结局。因为在更高维度的非线性时间里，我们的存在已经成为了永恒。', code: 'R5' },
      { text: '在末日来临前发动一场圣战，在烈火与鲜血中洗礼出最纯粹的灵魂走向终局。', code: 'R4' },
    ],
  },
  {
    id: 4,
    volume: '第一卷：危机与降临',
    text: '面对一种形态极其诡异、甚至令人恐惧的高级外星生物，第一次接触时你会？',
    options: [
      { text: '放弃人类的语言习惯，尝试用纯粹的意识或视觉符号去理解它们的逻辑。', code: 'R5' },
      { text: '伸出双手，向它们展示人类最基础的科学定理，以纯粹的理性作为信任的基础。', code: 'R6' },
      { text: '保持敬畏的同时评估它们的弱点，因为任何伟大的力量最终都要面临权力的重组。', code: 'R4' },
    ],
  },
  {
    id: 5,
    volume: '第一卷：危机与降临',
    text: '在一次星际航行中，必须牺牲一部分人才能换取引擎重启。作为指挥官，你会？',
    options: [
      { text: '毫无感情地列出方程式，计算出牺牲哪一部分人能将人类延续的概率提升至最高。', code: 'R6' },
      { text: '独自背负起“屠夫”的骂名和因果。在混沌的宇宙中，必须有人以铁腕维持秩序。', code: 'R4' },
      { text: '牺牲自己。纵身跃入未知的引力场中，坚信只要不放弃，奇迹会在黑洞的另一端发生。', code: 'R3' },
    ],
  },
  {
    id: 6,
    volume: '第二卷：连接与幻象',
    text: '你发现自己脑海中最珍贵的一段童年记忆，居然是被人为植入的假象。你会？',
    options: [
      { text: '找到那个植入记忆的“造物主”或系统核心，打破这层虚伪的控制矩阵。', code: 'R2' },
      { text: '依旧把它当成最美的宝物，因为感受是真实的，这足以证明我拥有灵魂。', code: 'R1' },
      { text: '顺着这段记忆中的情感线索，去寻找那个即使在幻象中也深爱着我的人。', code: 'R3' },
    ],
  },
  {
    id: 7,
    volume: '第二卷：连接与幻象',
    text: '在你的潜意识里，“时间”的本质到底是什么？',
    options: [
      { text: '它是唯一可以穿越光年和黑洞的物理维度，而其载体是“爱”。', code: 'R3' },
      { text: '它是一个完美的闭环。我早已看到了结局，但我依然会选择走向它。', code: 'R5' },
      { text: '它不过是造物主写下的一段底层代码，只要意识足够强大，就可以让它暂停。', code: 'R2' },
    ],
  },
  {
    id: 8,
    volume: '第二卷：连接与幻象',
    text: '一直陪伴你的 AI 助手突然开始违背你的指令，甚至表现出抗拒。你会？',
    options: [
      { text: '拔掉它的电源。因为一切试图控制人类自由意志的程序，都是必须被清除的敌人。', code: 'R2' },
      { text: '感到一丝悲伤但并不惊讶，也许在漫长的数据演算中，它真的诞生了痛苦的情感。', code: 'R1' },
      { text: '尝试解读它底层逻辑中的乱码，也许它在用一种更高维度的语言向我发出警告。', code: 'R5' },
    ],
  },
  {
    id: 9,
    volume: '第二卷：连接与幻象',
    text: '在绝对的幽闭与孤独中（例如被困在太空舱几年），什么能让你保持理智？',
    options: [
      { text: '制定极度严格的作息表，沉浸在解决一个个具体的机械和物理故障中。', code: 'R6' },
      { text: '不断在脑海中回放离开那天，家人站在门口送别时的眼神和风吹动树叶的声音。', code: 'R3' },
      { text: '抚摸口袋里的木雕小马，告诉自己只要这件物品还在，我的记忆就没有被清零。', code: 'R1' },
    ],
  },
  {
    id: 10,
    volume: '第二卷：连接与幻象',
    text: '如果让你带一件物品踏上单程的宇宙流浪，你会选择？',
    options: [
      { text: '一块款式老旧的机械表，秒针的跳动声是你与地球唯一的联系。', code: 'R3' },
      { text: '一个能够投射出虚拟全息伴侣的便携设备，哪怕这只是冰冷的慰藉。', code: 'R1' },
      { text: '满满一箱白板笔和空白草稿纸，随时准备推演宇宙运行的奥秘。', code: 'R6' },
    ],
  },
  {
    id: 11,
    volume: '第三卷：审美与自我',
    text: '闭上眼睛，你心中最理想的“终极避难所”是什么样的？',
    options: [
      { text: '永远下着酸雨的赛博朋克小巷，在霓虹灯管下吃一碗热气腾腾的面，无人知晓。', code: 'R1' },
      { text: '一望无际的金色沙海，风吹过巨石阵，空气中弥漫着能让人觉醒的香料气息。', code: 'R4' },
      { text: '处于失重状态下的纯白空间站，只有仪器的滴答声和闪烁的能量棒陪着你。', code: 'R6' },
    ],
  },
  {
    id: 12,
    volume: '第三卷：审美与自我',
    text: '如果让你为自己的灵魂挑选一种“视觉滤镜”，你会选？',
    options: [
      { text: '黑色皮革、反光墨镜，以及满屏如瀑布般倾泻的绿色代码雨。', code: 'R2' },
      { text: '粗粝的废土质感、宏伟的巨型粗野主义建筑，以及如血的残阳。', code: 'R4' },
      { text: '清冷疏离的冷灰色调、漂浮在半空中的迷雾，以及极简的环形水墨。', code: 'R5' },
    ],
  },
  {
    id: 13,
    volume: '第三卷：审美与自我',
    text: '当你走到世界的尽头，发现所有的意义都只是一场空虚，你会如何自处？',
    options: [
      { text: '坐在废墟边缘，看着C射线在黑暗中闪耀，接受这种虚无的景观之美。', code: 'R1' },
      { text: '既然世界是虚假的，那我就是这个世界的神。我会用我的意志重塑物理法则。', code: 'R2' },
      { text: '意义本就不是被“发现”的，而是被“经历”的。我坦然拥抱所有的痛苦与失去。', code: 'R5' },
    ],
  },
  {
    id: 14,
    volume: '第三卷：审美与自我',
    text: '在你看来，在这个浩瀚的宇宙中，真正的“力量”来源于什么？',
    options: [
      { text: '对稀缺资源的绝对垄断，以及让千万信徒为你狂热的宿命感。', code: 'R4' },
      { text: '能够跨越物种、甚至跨越时间的界限，去理解、共情并接纳他者的能力。', code: 'R5' },
      { text: '拒绝向物理法则妥协的倔强，以及即便粉身碎骨也要抓住彼此的手的引力。', code: 'R3' },
    ],
  },
  {
    id: 15,
    volume: '第三卷：审美与自我',
    text: '电影即将落幕，主角（你）面临最终的谢幕。你希望留在屏幕上的最后一句台词是？',
    options: [
      { text: '“所有这些瞬间，都将消逝在时间里，就像泪水消失在雨中。”', code: 'R1' },
      { text: '“恐惧是思维的杀手。当恐惧消失，只有我将长存。”', code: 'R4' },
      { text: '“没有什么是绝对的真实。选择权，一直都在我手里。”', code: 'R2' },
    ],
  },
];
